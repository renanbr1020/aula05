from django.contrib import admin
from contatos.models import Pessoa

# Register your models here.

admin.site.register (Pessoa)